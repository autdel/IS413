﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mission06_autdel.Models
{
    public class MoviesContext : DbContext
    {
        public MoviesContext (DbContextOptions<MoviesContext> options) : base (options)
        {

        }

        public DbSet<AddMovie> movies { get; set; }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<AddMovie>().HasData(
                new AddMovie
                {
                    MovieID = 1,
                    Title = "Interstellar",
                    Year = 2014,
                    Director = "Christopher Nolan",
                    Rating = "PG-13",
                    Edited = false,
                    LentTo = "Bob",
                    Notes = "Great movie"
                },
                new AddMovie
                {
                    MovieID = 2,
                    Title = "Inception",
                    Year = 2010,
                    Director = "Christopher Nolan",
                    Rating = "PG-13",
                    Edited = false,
                    LentTo = "Shelly",
                    Notes = "Such a cool movie"
                },
                new AddMovie
                {
                    MovieID = 3,
                    Title = "Avatar",
                    Year = 2009,
                    Director = "James Cameron",
                    Rating = "PG-13",
                    Edited = false,
                    LentTo = "Anna",
                    Notes = ""
                }
            );
        }
    }
}
