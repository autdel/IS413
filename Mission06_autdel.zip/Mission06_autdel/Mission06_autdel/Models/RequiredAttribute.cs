﻿using System;

namespace Mission06_autdel.Models
{
    internal class RequiredAttribute : Attribute
    {
    }
}