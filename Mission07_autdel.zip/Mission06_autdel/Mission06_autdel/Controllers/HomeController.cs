﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Mission06_autdel.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Mission06_autdel.Controllers
{
    public class HomeController : Controller
    {
        private MoviesContext moviesContext { get; set; }

        public HomeController(MoviesContext x)
        {
            moviesContext = x;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddMovies() // Loads the page to add movies
        {
            ViewBag.Categories = moviesContext.Categories.ToList();

            return View();
        }

        [HttpPost]
        public IActionResult AddMovies(AddMovie movie) // Saving the add movie form
        {
            if (movie.Edited.Equals(""))
            {
                movie.Edited.Equals(null);
            }
            if (ModelState.IsValid)
            {
                moviesContext.Add(movie);
                moviesContext.SaveChanges();

                return View("Confirmation", movie);
            }
            else
            {
                ViewBag.Categories = moviesContext.Categories.ToList();
                return View(movie);
            }

        }

        public IActionResult MyPodcasts()
        {
            return View();
        }

        public IActionResult AllMovies() // Loads page with all database records 
        {
            var movies = moviesContext.Movies.Include(x => x.Category).ToList();

            return View(movies);
        }

        // Edit saved movies
        public IActionResult Edit(int movieID)
        {
            ViewBag.Categories = moviesContext.Categories.ToList();

            var movie = moviesContext.Movies.Single(x => x.MovieID == movieID);

            return View("AddMovies", movie);
        }

        [HttpPost]
        public IActionResult Edit(AddMovie movie)
        {
            if (ModelState.IsValid)
            {
                moviesContext.Update(movie);
                moviesContext.SaveChanges();

                return RedirectToAction("AllMovies");
            }
            else
            {
                ViewBag.Categories = moviesContext.Categories.ToList();
                return View(movie);
            }
        }

        // Delete saved movies
        [HttpGet]
        public IActionResult Delete(int movieID)
        {
            var movie = moviesContext.Movies.Single(x => x.MovieID == movieID);

            return View(movie);
        }

        [HttpPost]
        public IActionResult Delete(AddMovie movie)
        {
            moviesContext.Remove(movie);
            moviesContext.SaveChanges();

            return RedirectToAction("AllMovies");
        }
    }
}
