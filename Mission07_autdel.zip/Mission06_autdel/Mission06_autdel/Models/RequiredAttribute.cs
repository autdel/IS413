﻿using System;

namespace Mission06_autdel.Models
{
    internal class RequiredAttribute : Attribute
    {
        public string ErrorMessage { get; set; }
        public bool AllowEmptyStrings { get; set; }
    }
}